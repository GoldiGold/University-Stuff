//
// Created by yoavst22 on 03/01/2020.
//

#include "ProgVar.h"
ProgVar::ProgVar(double val, std::string simulator) {
  this->value = val;
  this->sim = simulator;
}